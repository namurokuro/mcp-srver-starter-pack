"""
Blender MCP Server Addon
Installs and integrates the full MCP server repository into Blender
"""

bl_info = {
    "name": "MCP Server - Blender Integration",
    "author": "MCP Server Development Team",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar > MCP Tab",
    "description": "Full MCP Server integration with AI agents, generators, and tools",
    "category": "System",
    "doc_url": "https://github.com/namurokuro/mcp-srver-starter-pack",
    "tracker_url": "https://github.com/namurokuro/mcp-srver-starter-pack/issues",
}

import bpy
import sys
import os
from pathlib import Path

# Add MCP server path to Python path
def setup_mcp_path():
    """Add MCP server to Python path"""
    # Get addon directory
    addon_dir = Path(__file__).parent
    
    # Add addon directory to path
    addon_path = str(addon_dir)
    if addon_path not in sys.path:
        sys.path.insert(0, addon_path)
    
    # Also try to add parent mcp server directory if it exists
    parent_mcp = addon_dir.parent / "mcp server"
    if parent_mcp.exists():
        parent_path = str(parent_mcp)
        if parent_path not in sys.path:
            sys.path.insert(0, parent_path)
    
    return addon_path

# Setup path on import
MCP_ADDON_PATH = setup_mcp_path()

class MCP_PT_Panel(bpy.types.Panel):
    """MCP Server Control Panel"""
    bl_label = "MCP Server"
    bl_idname = "MCP_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "MCP"
    
    def draw(self, context):
        layout = self.layout
        
        # Status
        box = layout.box()
        box.label(text="Status", icon='INFO')
        
        # Check if MCP server modules are available
        try:
            import specialized_agents
            box.label(text="✓ MCP Server Loaded", icon='CHECKMARK')
        except ImportError:
            box.label(text="⚠ Modules Not Found", icon='ERROR')
            box.label(text="Check installation path")
        
        layout.separator()
        
        # Quick Actions
        box = layout.box()
        box.label(text="Quick Actions", icon='PLAY')
        
        op = box.operator("mcp.test_import", text="Test Import")
        op = box.operator("mcp.list_agents", text="List Agents")
        op = box.operator("mcp.check_status", text="Check Status")
        
        layout.separator()
        
        # Information
        box = layout.box()
        box.label(text="Information", icon='QUESTION')
        box.label(text="Path: " + MCP_ADDON_PATH[:50] + "...")
        box.operator("wm.url_open", text="GitHub Repository").url = "https://github.com/namurokuro/mcp-srver-starter-pack"

class MCP_OT_TestImport(bpy.types.Operator):
    """Test MCP Server Import"""
    bl_idname = "mcp.test_import"
    bl_label = "Test Import"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        try:
            from specialized_agents import ModelingSpecialist
            agent = ModelingSpecialist()
            self.report({'INFO'}, "✓ Import successful! MCP Server is working.")
            return {'FINISHED'}
        except ImportError as e:
            self.report({'ERROR'}, f"✗ Import failed: {e}")
            return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, f"✗ Error: {e}")
            return {'CANCELLED'}

class MCP_OT_ListAgents(bpy.types.Operator):
    """List Available Agents"""
    bl_idname = "mcp.list_agents"
    bl_label = "List Agents"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        try:
            from specialized_agents import get_available_agents
            agents = get_available_agents()
            agent_list = ", ".join(agents)
            self.report({'INFO'}, f"Available agents: {agent_list}")
            print(f"MCP Agents: {agent_list}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"Error: {e}")
            return {'CANCELLED'}

class MCP_OT_CheckStatus(bpy.types.Operator):
    """Check MCP Server Status"""
    bl_idname = "mcp.check_status"
    bl_label = "Check Status"
    bl_options = {'REGISTER', 'UNDO'}
    
    def execute(self, context):
        status_messages = []
        
        # Check Python path
        if MCP_ADDON_PATH in sys.path:
            status_messages.append("✓ Python path configured")
        else:
            status_messages.append("⚠ Python path not configured")
        
        # Check imports
        try:
            import specialized_agents
            status_messages.append("✓ specialized_agents available")
        except:
            status_messages.append("✗ specialized_agents not found")
        
        try:
            import data_collector
            status_messages.append("✓ data_collector available")
        except:
            status_messages.append("✗ data_collector not found")
        
        try:
            import media_handler
            status_messages.append("✓ media_handler available")
        except:
            status_messages.append("✗ media_handler not found")
        
        status = "\n".join(status_messages)
        self.report({'INFO'}, "Status check complete - see console")
        print("="*60)
        print("MCP SERVER STATUS")
        print("="*60)
        print(status)
        print("="*60)
        
        return {'FINISHED'}

# Registration
classes = [
    MCP_PT_Panel,
    MCP_OT_TestImport,
    MCP_OT_ListAgents,
    MCP_OT_CheckStatus,
]

def register():
    """Register addon"""
    for cls in classes:
        bpy.utils.register_class(cls)
    
    # Setup path
    setup_mcp_path()
    
    print("="*60)
    print("MCP Server Addon: Registered")
    print(f"Addon path: {MCP_ADDON_PATH}")
    print("="*60)
    print()
    print("You can now use MCP server functions in Blender:")
    print("  from specialized_agents import ModelingSpecialist")
    print("  agent = ModelingSpecialist()")
    print()

def unregister():
    """Unregister addon"""
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    print("MCP Server Addon: Unregistered")

if __name__ == "__main__":
    register()

